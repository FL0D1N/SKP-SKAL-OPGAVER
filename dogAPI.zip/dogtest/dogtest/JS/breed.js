﻿function BREED() {
    var breed = $("#breeds").children("option:selected").val();
    $.get("https://dog.ceo/api/breed/" + breed + "/images/random", function (data) {
        $(".dog-img").attr("src", data.message);
        $(".dog-img").attr("alt", breed);
    });
        
}