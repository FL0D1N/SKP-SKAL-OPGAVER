﻿var select = document.getElementById("breeds"); 
var request = new XMLHttpRequest();

request.open("GET", "https://dog.ceo/api/breeds/list", true);

request.onload = function () {
    var data = JSON.parse(this.response);
    var breeds = data.message;

    if (request.status >= 200 && request.status < 400) {
        for (var i = 0; i < breeds.length; i++) {
            var opt = document.createElement("option");
            opt.innerHTML = breeds[i];
            opt.value = breeds[i];
            select.appendChild(opt);
        }

    }
}
request.send();