﻿function RND() {
     $.get("https://dog.ceo/api/breeds/image/random", function (data) {
        $(".dog-img").attr("src", data.message)
        $(".dog-img").attr("alt", "random");

     });

}